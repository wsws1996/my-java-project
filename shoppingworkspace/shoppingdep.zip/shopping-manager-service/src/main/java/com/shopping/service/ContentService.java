package com.shopping.service;

import com.shopping.pojo.ShoppingResult;
import com.shopping.pojo.TbContent;

public interface ContentService {
	public ShoppingResult insertContent(TbContent content);
}
