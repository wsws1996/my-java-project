package com.shopping.service;

public interface ItemParamItemService {
	public String getItemParamByItemId(Long itemId);
}
